//============================================================================
// Name        : 10_q1.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
class Matrix{
	int** matrix;
	int rows;
	int cols;
public:

	Matrix()
	{
		rows=0;
		cols=0;
		matrix =nullptr;
	}
	Matrix (int i, int j):rows(i),cols(j)
	{
		matrix=new int*[rows];
		for(int i=0;i<rows;i++)
		{
			matrix[i]=new int[cols];
		}
		cout<<"allocated"<<endl;
	}

void initializeMatrix(int n){

	for(int i=0;i<rows;i++)
	{
		for(int j=0;j<cols;j++)
		{
			matrix[i][j]=n++;
		}
	}


}

void display(){

	for(int i=0;i<rows;i++)
	{
		for(int j=0;j<cols;j++)
		{
			cout<<matrix[i][j]<<" ";
		}
		cout<<endl;
	}


}
Matrix& operator=(const Matrix& other)
{
    if (this != &other)  // Avoid self-assignment
    {
        // Step 1: Deallocate existing memory
        for (int i = 0; i < rows; i++)
        {
            delete[] matrix[i];
        }
        delete[] matrix;

        // Step 2: Copy dimensions
        this->rows = other.rows;
        this->cols = other.cols;

        // Step 3: Allocate new memory
        this->matrix = new int*[rows];
        for (int i = 0; i < rows; i++)
        {
            this->matrix[i] = new int[cols];

            // Step 4: Deep copy values
            for (int j = 0; j < cols; j++)
            {
                this->matrix[i][j] = other.matrix[i][j];
            }
        }
    }

    return *this; // Return current object to allow chained assignments
}

Matrix (const Matrix&other)
{
	rows=other.rows;
	cols=other.cols;
	 matrix = new int*[rows];
	        for (int i = 0; i < rows; i++) {
	            matrix[i] = new int[cols];
	            for (int j = 0; j < cols; j++) {
	                matrix[i][j] = other.matrix[i][j];
	            }
	        }
	        cout << "Copied" << endl;

}



	~Matrix()
	{
		for(int i=0;i<rows;i++)
		{
		  delete[] matrix[i];
		}
		delete [] matrix;
	}
};

int main() {
	Matrix mat1(2, 3);
	Matrix mat2(3, 2);
	cout<<"Matrix 1 :"<<endl;
    mat1.initializeMatrix(1);
    mat1.display();
    cout<<endl;
    cout<<"Matrix 2 :"<<endl;
    mat2.initializeMatrix(7);
     mat2.display();
     //copy constructor won't be called here
     Matrix mat4;
     mat4 = mat1;
     cout << "Matrix 4:" << endl;
      mat4.display();
      Matrix mat5 = mat2;
      cout << "Matrix 5:" << endl;
      mat5.display();
	return 0;
}
