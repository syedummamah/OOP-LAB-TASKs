//============================================================================
// Name        : 10_q3.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
class Matrix
	{
		int rows;
		int cols;
		int **matrix;
public:
	Matrix (int i, int j):rows(i),cols(j)
	{
		matrix=new int*[rows];
		for(int i=0;i<rows;i++)
		{
			matrix[i]=new int[cols];
		}
		cout<<"allocated"<<endl;
	}
	void initializeMatrix(int n){

		for(int i=0;i<rows;i++)
		{
			for(int j=0;j<cols;j++)
			{
				matrix[i][j]=n++;
			}
		}


	}
	void display(){

		for(int i=0;i<rows;i++)
		{
			for(int j=0;j<cols;j++)
			{
				cout<<matrix[i][j]<<" ";
			}
			cout<<endl;
		}
	}
	void findPairsWithSum(int n){
		cout << "Pairs that sum to " << n << ":" << endl;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            for (int x = i; x < rows; x++) {
                for (int y = (x == i ? j + 1 : 0); y < cols; y++) {
                    if (matrix[i][j] + matrix[x][y] == n) {
                        cout << "(" << matrix[i][j] << ", " << matrix[x][y] << ")" << endl;
                    }
                }
            }
        }
    }
}
		~Matrix()
			{
				for(int i=0;i<rows;i++)
				{
				  delete[] matrix[i];
				}
				delete [] matrix;
			}
	};
int main() {
	  Matrix mat1(4, 4);
    mat1.initializeMatrix(1);
    
    cout << endl << "Displaying the matrix" << endl;
    mat1.display();

    cout << endl << "Testing code for target value = 12" << endl;
    mat1.findPairsWithSum(12);

    cout << endl << "Testing code for target value = 7" << endl;
    mat1.findPairsWithSum(7);

    cout << endl << "Testing code for target value = 18" << endl;
    mat1.findPairsWithSum(18);
	return 0;
}
