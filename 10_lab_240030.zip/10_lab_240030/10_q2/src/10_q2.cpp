//============================================================================
// Name        : 10_q2.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
class BankAccount{
	string accountNumber;
	string accountHolder;
	float balance;
public:
	BankAccount(string accNumber,string accHolder,float bal):accountNumber(accNumber),
	accountHolder(accHolder),balance(bal)

	{
		cout<<"constructed"<<endl;
	}
	void deposit(float money)
	{
		balance+=money;
	}
  void withdraw(float amount){
	  balance-=amount;
	  if(balance<0)
	  {
		  cout<<"insufficient balance"<<endl;
	  }

  }

  void displayAccountDetails()
  {
	  cout<<"account number:"<<endl;
	  cout<<accountNumber<<endl;
	  cout<<"account holder:"<<endl;
	  cout<<accountHolder<<endl;
	  cout<<"balance left:"<<endl;
	  cout<<balance<<endl;

  }
	~BankAccount()
	{
		cout<<"Account terminated"<<endl;
	}

};

int main() {
	BankAccount b1("0030","ummamah",1000.0);
	int dep;
	int withd;
	cout<<"Enter money to be deposited :"<<endl;
	cin>>dep;
	b1.deposit(dep);
	cout<<"Enter money to be withd:"<<endl;
	cin>>withd;
	b1.withdraw(withd);
	b1.displayAccountDetails();
	return 0;
}
