//============================================================================
// Name        : 7q5.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
struct Fraction{

	int numerator,denominator;


};
 void initialize(Fraction &f){
	 cout<<"enter numerator and denominator"<<endl;
	 cin>>f.numerator;
	 do{
		 cout<<"enter non-zero denominator"<<endl;
	 cin>>f.denominator;
	 }
	 while(f.denominator==0);
 }
 void display(Fraction &f){
 	cout<<f.numerator<<"/"<<f.denominator<<endl;

  }


 //addition

 Fraction add(const Fraction &f1,const Fraction& f2){

	 Fraction result;
	 result.numerator=f1.numerator*f2.denominator + f2.numerator*f1.denominator;
	 result.denominator = f1.denominator * f2.denominator;
	     return result;
 }
//subtraction

 Fraction subs(const Fraction &f1,const Fraction&f2)
 {
	 Fraction result;
result.numerator=f1.numerator*f2.denominator -f1.denominator*f2.numerator;
	 result.denominator=f1.denominator*f2.denominator;
	 return result;
 }
 //multiplication
 Fraction multiply(const Fraction &f1,const Fraction &f2 )
 {
	 Fraction result;
	 result.numerator=f1.numerator*f2.numerator;
	 result.denominator=f1.denominator*f2.denominator;
	 return result;

 }

 Fraction division(const Fraction &f1,const Fraction &f2 )
  {
 	 Fraction result;
 	 result.numerator=f1.numerator*f2.denominator;
 	 result.denominator=f1.denominator*f2.numerator;
 	 return result;

  }



int main() {
	Fraction f1,f2,final;
	Fraction result;
	cout<<"Enter first fraction"<<endl;
	initialize(f1);
	cout<<"Enter second fraction"<<endl;
	initialize(f2);

	cout<<"first fraction"<<endl;
	display(f1);
	cout<<"second fraction"<<endl;
		display(f2);

		cout<<endl;
		 final = add(f1, f2);
		    cout << "\nAddition: ";
		    display(final);

		    cout<<endl;
	result=subs(f1,f2);
	cout<<"substraction"<<endl;
	display(result);

	final=multiply(f1,f2);
	cout<<"multiplication"<<endl;
	display(final);

	final=division(f1,f2);
		cout<<"division"<<endl;
		display(final);



	return 0;
}



