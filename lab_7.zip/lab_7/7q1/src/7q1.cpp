//============================================================================
// Name        : 7q1.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
struct Student {
	string name;
	int age ;
	float marks;
};
int main() {

	Student s1;
	cout<<"enter marks:"<<endl;
	cin>>s1.marks;
	cout<<"enter name:"<<endl;
	cin>>s1.name;
	cout<<"enter age:"<<endl;
	cin>>s1.age;

	cout<<"name:"<<s1.name<<endl<<"age:"<<s1.age<<endl<<"marks:"<<s1.marks<<endl;


	return 0;
}
