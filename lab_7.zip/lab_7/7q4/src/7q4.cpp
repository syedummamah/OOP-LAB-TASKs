//============================================================================
// Name        : 7q4.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
struct Book {
	string author;
	string name;
	int price;
};
int main() {

	Book b[3];
	for(int i=0;i<3;i++)
	{    cout<<"enter name, author and price for book number "<<i+1<<":"<<endl;
		cin>>b[i].name;
		cin>>b[i].author;
		cin>>b[i].price;

	}
	for(int i=0;i<3;i++)
		{    cout<<"details for book number "<<i+1<<":"<<endl;
			cout<<"Name of book :"<<b[i].name;
			cout<<endl;
			cout<<"Author of book :"<<b[i].author;
			cout<<endl;
			cout<<"Price of book :"<<b[i].price;
			cout<<endl;

		}

	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!
	return 0;
}
