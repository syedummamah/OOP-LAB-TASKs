//============================================================================
// Name        : 7q2.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
struct Rectangle{
	float length,width;

	/* float calculateArea(float l,float w)
	{
		return l*w;
	}*/

 float calculateArea()
	{
		return length*width;
	}
};
int main() {
	Rectangle R1;
	cout<<"enter length"<<endl;
	cin>>R1.length;
	cout<<"enter width"<<endl;
	cin>>R1.width;
	//cout<<R1.calculateArea(R1.length,R1.width);
	cout<<R1.calculateArea();


	return 0;
}
