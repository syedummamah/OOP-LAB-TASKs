//============================================================================
// Name        : 7q3.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
struct Circle{
	float radius;
};

float getArea(Circle c)
{
	return 3.14*c.radius*c.radius;
}

int main() {
	Circle c;
	cout<<"enter radius"<<endl;
	cin>>c.radius;
cout<<	getArea(c);
	return 0;
}
