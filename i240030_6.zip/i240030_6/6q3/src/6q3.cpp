//============================================================================
// Name        : 6q3.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
int find(int array[],int length,int target)
{
	if(length==0)
	{
		return -1;
	}
	if(array[length-1]==target)
	{
		return length-1;
	}

	return find(array, length-1,target);
}

int main() {
	int size;
	int array[size];
	int target;
	cout<<"Enter target digit"<<endl;
	cin>>target;
	cout<<"Enter the size"<<endl;
	cin>>size;
	cout<<"Enter array terms"<<endl;
	for(int i=0;i<size;i++)
	{
		cin>>array[i];
	}


cout<<find( array,size, target);

	return 0;
}
