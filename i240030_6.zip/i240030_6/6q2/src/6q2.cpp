//============================================================================
// Name        : 6q2.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
int countChocolates(int wrappers, int wrap) {
    if (wrappers < wrap)
    return 0;
    int newChocolates = wrappers / wrap;
    return newChocolates + countChocolates(newChocolates + (wrappers % wrap), wrap);
}


int maxChocolates(int money, int price, int wrap) {
    if (price <= 0 || wrap <= 0)

    return 0;

    int chocolates = money / price;
    return chocolates + countChocolates(chocolates, wrap);
}

int main() {

	int money,price,wraps;
	cout<<"Enter Money"<<endl;
	cin>>money;
	cout<<"Enter price"<<endl;
    cin>>price;
    cout<<"Enter wraps"<<endl;
    cin>>wraps;

   cout<< maxChocolates(money,price,wraps);
	//cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!
	return 0;
}
