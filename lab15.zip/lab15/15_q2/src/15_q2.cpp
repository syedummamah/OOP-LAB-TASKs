//============================================================================
// Name        : 15_q2.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#include <iostream>
#include <fstream>

using namespace std;

class Quiz {
public:
    struct MCQ {
        string question;
        string option1;
        string option2;
        string option3;
        string option4;
        string correctOption;
    };

    int readfile(string filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            cout << "Could not open file!" << endl;
            return 0;
        }

        MCQ q;
        int score = 0;
        string userAnswer;

        while (getline(file, q.question, ':')) {
            getline(file, q.option1, ':');
            getline(file, q.option2, ':');
            getline(file, q.option3, ':');
            getline(file, q.option4, ':');
            getline(file, q.correctOption);

            // Displaying question and options
            cout << "question: " << q.question << endl;
            cout << "option1: " << q.option1 << endl;
            cout << "option2: " << q.option2 << endl;
            cout << "option3: " << q.option3 << endl;
            cout << "option4: " << q.option4 << endl;

            cout << "Your answer: ";
            cin >> userAnswer;

            if (userAnswer == q.correctOption) {
                score++;
            } else {
                cout << "wrong, correct option is " << q.correctOption << endl;
            }

            cout << endl;
        }

        file.close();
        cout << "Final Score: " << score << endl;
        return score;
    }
};

int main() {
    Quiz quiz;
    quiz.readfile("question.txt");
    return 0;
}

