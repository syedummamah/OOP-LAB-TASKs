//============================================================================
// Name        : 15_q3.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
using namespace std;


struct Student {
    char name[50];
    int rollNumber;
    int age;
};

int main() {
    // Create a student object and fill data
    Student student1;
    cout << "Enter name: ";
    cin.getline(student1.name, 50);
    cout << "Enter roll number: ";
    cin >> student1.rollNumber;
    cout << "Enter age: ";
    cin >> student1.age;

    //.dat is binary file 
    ofstream outFile("student.dat", ios::binary);
    if (outFile) {
        outFile.write(reinterpret_cast<char*>(&student1), sizeof(student1));
        outFile.close();
        cout << "Student written to file successfully."<<endl;
    } else {
        cout << "Error writing to file."<<endl;
    }

    // Read the student data into student2
    Student student2;
    ifstream inFile("student.dat", ios::binary);
    if (inFile) {
        inFile.read(reinterpret_cast<char*>(&student2), sizeof(student2));
        inFile.close();

        // Display read data
        cout << "\nStudent read from file:"<<endl;
        cout << "Name: " << student2.name << endl;
        cout << "Roll Number: " << student2.rollNumber << endl;
        cout << "Age: " << student2.age << endl;
    } else {
        cout << "Error reading from file."<<endl;
    }

    return 0;
}

