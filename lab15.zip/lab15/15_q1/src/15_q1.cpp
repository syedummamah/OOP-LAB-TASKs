//============================================================================
// Name        : 15_q1.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

//super class
class Student {
protected:
    string name;
    int age;
public:
    Student(string n, int a) : name(n), age(a) {}
    virtual void display() = 0;
    virtual ~Student() {}
};

// Derived class
class BachelorStudent : public Student {
    string major;
public:
    BachelorStudent(string n, int a, string m) : Student(n, a), major(m) {}
    void display() override {
        cout << "Student Type: Bachelor" << endl;
        cout << "Name: " << name << ", Age: " << age << ", Major: " << major << endl;
    }
};

class MasterStudent : public Student {
    string researchTopic;
    int researchYears;
public:
    MasterStudent(string n, int a, string topic, int years)
        : Student(n, a), researchTopic(topic), researchYears(years) {}
    void display() override {
        cout << "Student Type: Master" << endl;
        cout << "Name: " << name << ", Age: " << age
             << ", Research Topic: " << researchTopic
             << ", Research Years = " << researchYears << endl;
    }
};

// Academy class
class Academy {
    Student* students[4];  // Array of pointers to base class
    int studentCount;
public:
    Academy() {
        studentCount = 0;
    }

    // Add Bachelor student
    void addStudent(string name, int age, string major) {
        if (studentCount < 4) {
            students[studentCount++] = new BachelorStudent(name, age, major);
        }
    }

    // Add Master student (overloaded)
    void addStudent(string name, int age, string topic, int years) {
        if (studentCount < 4) {
            students[studentCount++] = new MasterStudent(name, age, topic, years);
        }
    }

    void displayStudents() {
        for (int i = 0; i < studentCount; i++) {
            students[i]->display();
        }
    }

    ~Academy() {
        for (int i = 0; i < studentCount; i++) {
            delete students[i];
        }
    }
};

int main() {
    Academy academy;
    academy.addStudent("Alice", 20, "Computer Science");
    academy.addStudent("Charlie", 21, "Mechanical Engineering");
    academy.addStudent("Bob", 25, "Artificial Intelligence", 2);
    academy.addStudent("David", 26, "Data Science", 1);

    academy.displayStudents();

    return 0;
}
