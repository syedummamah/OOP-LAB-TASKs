#include "lab1.cpp"
#include <gtest/gtest.h>

TEST(Divide,allNumbers) { 
    ASSERT_EQ(6.0, divide(36.0,6.0));
    ASSERT_EQ(4.0, divide(-44,-11));
    ASSERT_EQ(-5.4, divide(25.16,-5.0));
    ASSERT_EQ(-1, divide(0.0,0.0));
}


TEST(factorial,allnumbers) {
    ASSERT_EQ(-1, factorial(-15));
    ASSERT_EQ(120, factorial(5));
    ASSERT_EQ(1, factorial(0));
}

TEST(greater,allnumbers) {
    ASSERT_EQ(8, greater(-20,8));
    ASSERT_EQ(0, greater(0,0));
    ASSERT_EQ(56, greater(5,56));
    
}

TEST(Vowel,allnumbers) {
char word1[50]="Hi i am ali";
    ASSERT_EQ(5, count(word1));
    char word2[50]="aeiou";
    ASSERT_EQ(5, count(word2));
    char word3[50]="lyly";
    ASSERT_EQ(0, count(word3));
    
}

TEST(Sumation,allnumbers) {
int arr1[5]={1,2,3,4,5};
    ASSERT_EQ(15, sum(arr1));
    int arr2[5]={5,10,15,20,25};
    ASSERT_EQ(5, sum(arr2));
    int arr3[5]={0,0,0,0,0};
    ASSERT_EQ(0, sum(arr3));
    
}

TEST(Prime,allnumbers) {
    ASSERT_EQ(false, isPrime(1));
    ASSERT_EQ(true, isPrime(7));
    ASSERT_EQ(false, isPrime(20));
    
}



int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
