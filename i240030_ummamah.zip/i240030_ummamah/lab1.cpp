#include <string>
#include<iostream>
//using namespace std;

float quotient(float dividend, float divisor ){
if(divisor==0)
{return -1;}
return dividend/divisor;
}

int computeFactorial(int num){
if(num<0)
{return -1;}
int result = 1;
while(num>1){
result *= num--;
}
return result;
}

int maxNumber(int num1, int num2){
if(num1>num2){
return num1;
}
if(num2>num1){
return num2;
}
return num1; // If both are equal
}

int countVowels(char text[50]){
int vowels = 0;
for(int i=0;i<50;i++){
if(text[i]=='a'||text[i]=='e'||text[i]=='i'||text[i]=='o'||text[i]=='u'||text[i]=='A'||text[i]=='E'||text[i]=='I'||text[i]=='O'||text[i]=='U')
{++vowels;}
}
return vowels;
}

int arraySum(int numbers[5]){
int total = 0;
for(int i=0;i<5;i++){
total += numbers[i];
}
return total;
}

bool checkPrime(int value){
    if(value<2) return false;
    for(int i=2;i*i<=value;i++){ 
        if (value%i==0) return false;
    }
    return true; 
}    
