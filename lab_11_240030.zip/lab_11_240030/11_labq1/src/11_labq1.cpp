//============================================================================
// Name        : 11_labq1.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
class MathOperations{
    int num;
public:
    MathOperations(int num1) : num(num1){}
    MathOperations(){}

MathOperations& operator+(const MathOperations&other){

	this->num+=other.num;
	return*this;
}
  void display(const MathOperations&m ){

	  cout<<m.num;
  }
  void Display()
  {
	  cout<<"called second display"<<num;
  }
  ~ MathOperations(){
	  cout<<"destroyed"<<endl;
  }

};

int main() {

	MathOperations m1(10);
	MathOperations m2(10);
	MathOperations m3;
	m1=m1+m2;
 m1.display(m1);
 cout<<endl;
 m1.Display();



	return 0;
}
