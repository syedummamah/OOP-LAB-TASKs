//============================================================================
// Name        : 11_q3.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class Matrix{
	int rows;
	int cols;
	int**ptr;
public:
	Matrix(){}
	Matrix(int r,int c) :rows(r),cols(c){
		ptr=new int*[rows];
		for(int i=0;i<rows;i++)
		{
			ptr[i]=new int [cols];
		}
	}
void initialize(int n){
	for(int i=0;i<rows;i++)
	{
		for(int j=0;j<cols;j++)
		{
			ptr[i][j]=n++;
		}

	}
}

 void display(){
	 for(int i=0;i<rows;i++)
	 	{
	 		for(int j=0;j<cols;j++)
	 		{
	 			cout<<ptr[i][j];
	 		}
	 		cout<<endl;
	 	}

 }
 Matrix operator=(const Matrix&other)
 {
	 for(int i=0;i<rows;i++)
	 {
		 delete [] ptr[i];
	 }
	 delete[]ptr;

	 ptr=new int*[rows];
	 for(int j=0;j<cols;j++)
	 {
		ptr=new int [cols];
	 }
 }
Matrix operator*(const Matrix&other){

	if(this->cols==other.rows){

	   Matrix temp( rows,other.cols);
		for(int i=0;i<rows;i++)
		{
			for(int j=0;j<other.cols;j++)
			{
				for(int k=0;k<rows;k++)
				{
					temp.ptr[i][j]+=ptr[i][k]+other.ptr[k][j];
				}
			}
			 return temp;
		}

	}
}
};

int main() {
	Matrix m;
	Matrix m1(2,3);
	m1.initialize(0);
	m1.display();
	Matrix m2(3,2);
	m2.initialize(1);
	m2.display();
    m1=m1*m2;
    m1.display();
	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!
	return 0;
}
