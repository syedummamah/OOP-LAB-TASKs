//============================================================================
// Name        : 11_q2.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class Counter{
	int count;
public:
	Counter()
	{
		count=0;
	}

	Counter(int i)
		{
			count=i;
		}

 Counter operator++(int)
{
	 Counter temp;
	 temp.count = this->count + 1;
     return temp;

}
 Counter operator++()
 		{
 	       this->count+=1;
 	       return *this;
 		}
 void Display()
 {
	 cout<<this->count;
 }
~Counter()
{
	cout<<"dest"<<endl;
}
};

int main() {
	Counter c1=10;
	Counter y;

	// c1++;
(++c1).Display();


	return 0;
}
