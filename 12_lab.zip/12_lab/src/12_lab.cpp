//============================================================================
// Name        : 12_lab.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
class Matrix{
	int rows;
	int cols;
	int**ptr;
public:
	Matrix(int r,int c): rows(r),cols(c){
		ptr=new int*[rows];
		for(int i=0;i<rows;i++)
		{
			ptr[i]=new int [cols];
		}
		cout<<"constructed"<<endl;
	}
	Matrix(const Matrix & other ):rows(other.rows),cols(other.cols){
		ptr=new int*[rows];
				for(int i=0;i<rows;i++)
				{
					ptr[i]=new int [cols];
				}
				cout<<"constructed"<<endl;

	for(int i=0;i<rows;i++)
			{
				for(int j=0;j<cols;j++)
				{
					ptr[i][j]=other.ptr[i][j];
				}
			}



}
	/*void initialize(){
		       for(int i=0;i<rows;i++)
		{
					for(int j=0;j<cols;j++)
					{
						cin>>ptr[i][j];//=+other.ptr[i][j];
					}
				}
	}*/
	Matrix operator+(const Matrix&other)
	{  Matrix result(rows,cols);
		for(int i=0;i<rows;i++)
		{
			for(int j=0;j<cols;j++)
			{
				result.ptr[i][j]=this->ptr[i][j]+other.ptr[i][j];
			}
		}
		return result;
	}
	bool operator==(const Matrix &other)
		{
		  if(rows!=other.rows)
		  {
			  return false;
		  }
		  for(int i=0;i<rows;i++)
		  		{
		  			for(int j=0;j<cols;j++)
		  			{
		  				if(ptr[i][j] != other.ptr[i][j]) {
		                    return false;
		  			}
		  		}
					}
		  return true;
		}
	friend ostream& operator<<(ostream&out,const Matrix&m){
		for(int i=0;i<m.rows;i++)
		{
			for(int j=0;j<m.cols;j++)
			{
				out<<m.ptr[i][j]<<" ";
			}
			cout<<endl;
		}
		return out;
	}
	friend istream& operator>>(istream&in,const Matrix&m){
			for(int i=0;i<m.rows;i++)
			{
				for(int j=0;j<m.cols;j++)
				{
					in>>m.ptr[i][j];
				}
				cout<<endl;
			}
			return in;
		}

	void display()
	{
		for(int i=0;i<rows;i++)
				{
					for(int j=0;j<cols;j++)
					{
						cout<<ptr[i][j];
				}
					cout<<endl;
	}
}
    // Destructor
    ~Matrix() {
        for (int i = 0; i < rows; i++) {
            delete[] ptr[i];
        }
        delete[] ptr;
    }

};
int main() {
	Matrix m1(1,1);
	Matrix m2(1,1);
   cout<<"enter elemnets for matrix 1"<<endl;
   cin>>m1;
   cout<<"enter elemnets for matrix 2"<<endl;
      cin>>m2;

	Matrix m3 = m1 + m2;;
	cout<<"elements for matrix 1 are"<<endl;
	   cout<<m1;
	   cout<<endl;
	   cout<<"elements for matrix 2 are"<<endl;
	   	   cout<<m1;
	   	   cout<<endl;
	   	cout<<"elements for matrix 3(sum of 1 and 2) are"<<endl;
	   		   cout<<m3;
  cout<<endl;

	if(m1==m2)
  {
	  cout<<"matrixes are equal"<<endl;
  }
  else
  {
	  cout<<"matrixes are not equal"<<endl;
  }

	return 0;
}
