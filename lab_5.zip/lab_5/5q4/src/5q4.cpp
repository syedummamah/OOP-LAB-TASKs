//============================================================================
// Name        : 5q4.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

void helper(int count, char ch) {
	cout<<' ';
	if(count==0)
	{
		cout<<ch;
		return;
	}
	helper(count-1,ch);


return;

}

void pattern(int rows) { // Don't modify the prototype
     if(rows==0)
     {
    	 return;
     }

	helper(rows-1,'*');
	cout<<endl;
	pattern(rows-1);


	helper(rows-1,'0');
	cout<<endl;



}

// Don't modify the main
int main() {
    int n;
    cout << "enter rows\n";
    cin >> n;

    pattern(n);


}
