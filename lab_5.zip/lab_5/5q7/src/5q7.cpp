//============================================================================
// Name        : 5q7.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
int sum(int array[],int size,int sign)
{
	if(size<=0)
	{
		return 0;
	}
  return sign*array[0]+sum(array+1,size-1,-sign);
}

int main() {
	int arr[5]={1,2,3,4,5};
	int size=5;
	cout<<sum(arr,size,1);
	return 0;
}
