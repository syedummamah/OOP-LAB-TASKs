//============================================================================
// Name        : 5q5.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

bool isSorted(int* arr, int size) {

    if (size <= 1) {
        return true;
    }

    if (arr[0] > arr[1]) {
        return false;
    }


    return isSorted(arr + 1, size - 1);
}

int main() {
    int arr[] = {1, 2, 3, 4, 5};
    int size =5;

    if (isSorted(arr, size)) {
        cout << "The array is sorted." << endl;
    } else {
        cout << "The array is not sorted." << endl;
    }

    return 0;
}
