//============================================================================
// Name        : 5q6.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int sumEvenIndices(int* arr, int size, int index) {

    if (index >size) {
        return 0;
    }


    return arr[index] + sumEvenIndices(arr, size, index + 2);
}

int main() {
    int arr[] = {1, 2, 3, 4, 5};
    int size = 5;


    int sum = sumEvenIndices(arr, size, 0);
    cout << "Sum of elements at even indices: " << sum << endl;

    return 0;
}
