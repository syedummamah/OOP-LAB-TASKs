//============================================================================
// Name        : 5q3.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

void allocate(int *&arr, int size=5) {

       arr=new int[5];
}

void initialize(int *&arr, int size, int initialNum) {
    for (int i = 0; i<size; i++) {
        arr[i] = initialNum++;
    }
}

void displayArray(int *&arr, int size) {
    for (int i = 0; i<size; i++) {
        cout << arr[i] << " ";
    }
}

void question2(int *array, int i = 0) { // Don't modify the prototype

	if(i==5)
	{
		return ;

	}
	question2(array,i+1);
	cout<<array[i]<<" ";

  return;
}

// Don't modify the main
int main() {
    int *n;
    allocate(n,5);
    initialize(n,5,3);

    cout << endl << "Displaying array elemets " << endl;
    displayArray(n,5);
    cout<< endl;

    cout << endl << "Displaying array elemets in reverse order " << endl;
    question2(n);
    cout << endl;

}
