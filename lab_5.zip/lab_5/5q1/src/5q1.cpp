//============================================================================
// Name        : 5q1.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
int factorial(int n)
{
	if(n==0)
	{
		return 1;
	}
	if(n<0)
	{
		cout<<"Enter a positive number";
		return 0;
	}
 return	n*factorial(n-1);
}

int main() {
    int num;
    cout << "Enter a number: ";
    cin >> num;

    if (num < 0)
        cout << "Factorial is not defined for negative numbers." << endl;
    else
        cout << "Factorial of " << num << " is " << factorial(num) << endl;

    return 0;
}
