//============================================================================
// Name        : 5q2.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
int question6(char*ptr)
{
	if(*ptr=='\0')
	{
		return 0;
	}

	return 1+ question6(ptr+1);
}

int main() {
    cout << "Enter the string ";
    char *array = new char [10];
    cin >> array;
    cout << "length = " << question6(array) << endl;
    delete array;
    return 0;
}
