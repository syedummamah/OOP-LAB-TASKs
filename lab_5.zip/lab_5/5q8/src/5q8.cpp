//============================================================================
// Name        : 5q8.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

void helper(int count) {

	if(count==0)
	{
		return;
	}
	cout<<" ";
	helper(count-1);
}

void pattern(int rows,int index=0) { // Don't modify the prototype

	if(rows==0)
	{
		return;
	}
	helper(index);
	cout<<'*';
	helper(2*(rows-1));
	cout<<'0';
	cout<<endl;

	pattern(rows-1,index+1);

	helper(index);
		cout<<'0';
		helper(2*(rows-1));
		cout<<'*';
		cout<<endl;



}

// Don't modify the main
int main() {
    int n;
    cout << "enter rows\n";
    cin >> n;

    pattern(n);


}
