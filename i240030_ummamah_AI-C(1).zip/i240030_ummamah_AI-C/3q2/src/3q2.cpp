//============================================================================
// Name        : 3q2.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
void allocateMemory(int*&age,int numstudents)
{
	age=new int[numstudents];
}
void allocateMemory(char*&gender,int numstudents)
{
	gender=new char[numstudents];

}

 void allocateMemory(string*&name,int numstudents)
 {
	 name=new string[numstudents];

 }



 void initialize(int*age,int numstudents)
 {    cout<<"enter student age: "<<endl;
	 for(int i=0;i<numstudents;i++)
		 cin>>age[i];
 }
 void initialize(char*gender,int numstudents)
  {    cout<<"enter student gender: "<<endl;
 	 for(int i=0;i<numstudents;i++)
 		 cin>>gender[i];
  }
 void initialize(string*name,int numstudents)
   {    cout<<"enter name students"<<endl;

  	 for(int i=0;i<numstudents;i++){
  		 cin>>name[i];
  	 }
   }
 void display(int*age,char*gender,string*name,int size)
 {
	 for(int i=0;i<size;i++)
	 {  int j=0;
		 cout<<++j<<". "<<"Name"<<endl<<name[i]<<endl<<"Age:"<<age[i]<<endl<<"Gender:"<<gender[i]<<endl;
	 }
 }
int main() {

	int numstudents;
	cout<<"Enter no. of students";
	cin>>numstudents;
	int* age;
	char* gender;
	string* name;
	allocateMemory(age,numstudents);
	allocateMemory(gender,numstudents);
    allocateMemory(name,numstudents);


    initialize(age,numstudents);
    initialize(gender,numstudents);
    initialize(name,numstudents);

    display(age,gender,name,numstudents);
    delete [] age;
    delete[] gender;
    delete[] name;


	return 0;
}
