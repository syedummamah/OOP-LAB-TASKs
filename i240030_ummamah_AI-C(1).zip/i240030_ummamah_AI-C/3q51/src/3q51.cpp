//============================================================================
// Name        : 3q51.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include<iostream>
using namespace std;

int targetsum(int*ptr,int size,int target)
{
	cout<<"the pairs for target sum :"<<target<<" can be"<<endl;
	int count=0;
	for(int i=0;i<size;i++)
	{
		for(int j=i+1;j<size;j++)
		{
			if(ptr[i]+ptr[j]==target)
				{
				cout<<"("<<*(ptr+i)<<","<<*(ptr+j)<<")"<<endl;
				count++;
				}
		}
	}



	return count;


}






int main()
{
	int*ptr;
	int size;
	int target;
	cout<<"enter size of array:"<<endl;
	cin>>size;
	ptr=new int [size];
	cout<<"enter "<<size<<" elements:"<<endl;

	for(int i=0; i<size;i++)
	{
		cin>>ptr[i];

	}
	cout<<"enter the target sum"<<endl;
	cin>>target;

   cout<< targetsum(ptr,size,target);









}














