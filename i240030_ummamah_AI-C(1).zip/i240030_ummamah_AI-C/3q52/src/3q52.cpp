//============================================================================
// Name        : 3q52.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

void sort(int*ptr,int size)
{
	for(int i=0;i<size-1;i++)
	{   for(int j=i+1;j<size;j++)
	{
		if(ptr[i]>ptr[j])
		{
			int temp=ptr[i];
			ptr[i]=ptr[j];
			ptr[j]=temp;
		}

	}


	}

}

int main() {


		int*ptr;
		int size;
		cout<<"enter size of array:"<<endl;
		cin>>size;
		ptr=new int [size];
		cout<<"enter "<<size<<" elements:"<<endl;

		for(int i=0; i<size;i++)
		{
			cin>>ptr[i];

		}
		sort(ptr,size);
		for(int i=0;i<size;i++)
		{
			cout<<ptr[i]<<" ";
		}
        delete[] ptr;
		return 0;
}






