//============================================================================
// Name        : 3q3.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#include <iostream>
using namespace std;


void allocateMemory(char*& arr, int size) {
    arr = new char[size];
}


void initialize(char* arr, int size) {
    cout << "Enter characters: ";
    for (int i = 0; i < size; i++) {
        cin >> *(arr + i);
    }
}


void displayArray(const char* arr, int size) {
    cout << "Array: ";
    for (int i = 0; i < size; i++) {
        cout << *(arr + i) << " ";
    }
    cout << endl;
}


void reverseArray(char* arr, int size) {
    char* left = arr;
    char* right = arr + size - 1;

    while (left < right) {

        char temp = *left;
        *left = *right;
        *right = temp;


        left++;
        right--;
    }
}


bool isPalindrome(const char* arr, int size) {
    const char* left = arr;
    const char* right = arr + size - 1;

    while (left < right) {
        if (*left != *right) {
            return false;
        }
        left++;
        right--;
    }
    return true;
}

int main() {
    int size;
    char* arr;

    cout << "Enter size of array: ";
    cin >> size;

    allocateMemory(arr, size);
    initialize(arr, size);

    cout << "\nOriginal ";
    displayArray(arr, size);

    reverseArray(arr, size);
    cout << "\nReversed ";
    displayArray(arr, size);

    if (isPalindrome(arr, size)) {
        cout << "\nThe array is a palindrome.\n";
    } else {
        cout << "\nThe array is not a palindrome.\n";
    }

    // Deallocate memory
    delete[] arr;

    return 0;
}
