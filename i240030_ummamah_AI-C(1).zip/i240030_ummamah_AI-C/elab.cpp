#include <iostream>
#include <string>
using namespace std;

// String array initialized with provided values
string dictionary[109] = {
    "cat", "dog", "bat", "hat", "run", "sun", "red", "blue", "pen", "cup",
    "fish", "bird", "rose", "tree", "lake", "moon", "star", "fork", "lamp", "book",
    "play", "pool", "rose", "silk", "song", "ship", "tile", "vest", "wish", "zoom",
    "case", "drop", "face", "gold", "jump", "kick", "lime", "nose", "ring", "tail",
    "cloud", "crawl", "dream", "fresh", "grain", "happy", "juice", "lucky", "music", "piano",
    "queen", "quick", "smile", "storm", "toast", "umbra", "video", "wrist", "zebra", "world",
    "apple", "brave", "chess", "drink", "flame", "grape", "jazz", "lemon", "novel", "pride",
    "quest", "route", "shoe", "trace", "unity", "vivid", "water", "xerox", "yellow", "zesty",
    "silver", "orange", "camera", "travel", "window", "floral", "banana", "purple", "turkey",
    "magnet", "branch", "guitar", "impact", "castle", "pickle", "forest", "oliver", "planet", "summer",
    "a", "i", "on", "up", "by", "go", "no", "us", "it", "as"
};

void fillGrid(char** grid, int rowCount, int colCount) {
    cout << "Enter " << rowCount << " rows of words (each row must have " << colCount << " characters):\n";
    for (int r = 0; r < rowCount; r++) {
        for (int c = 0; c < colCount; c++) {
            cin >> grid[r][c];
        }
    }
}

bool checkWord(string givenWord) {
    for (int i = 0; i < 109; i++) {
        if (dictionary[i] == givenWord) {
            return true;
        }
    }
    return false;
}

void extractWords(char** grid, int rowCount, int colCount) {
    cout << "\nWords found in dictionary:\n";
    for (int r = 0; r < rowCount; r++) {
        for (int start = 0; start < colCount; start++) {
            for (int end = start; end < colCount; end++) {
                string currentWord = "";
                for (int k = start; k <= end; k++) {
                    currentWord += grid[r][k];
                }
                if (checkWord(currentWord)) {
                    cout << currentWord << endl;
                }
            }
        }
    }
}

int main() {
    int rowCount, colCount;
    cout << "Enter number of rows and columns: ";
    cin >> rowCount >> colCount;
    
    char** grid = new char*[rowCount];
    for (int r = 0; r < rowCount; r++) {
        grid[r] = new char[colCount];
    }
    
    fillGrid(grid, rowCount, colCount);
    extractWords(grid, rowCount, colCount);
    
    for (int r = 0; r < rowCount; r++) {
        delete[] grid[r];
    }
    delete[] grid;
    
    return 0;
}

