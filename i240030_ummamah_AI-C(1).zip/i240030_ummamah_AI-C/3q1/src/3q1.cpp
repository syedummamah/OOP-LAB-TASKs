//============================================================================
// Name        : 3q1.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================


#include <iostream>
using namespace std;

void allocateMemory(int*&ptr,int size)
{   ptr=new int[size];

}
void initialize(int* ptr,int size)
{
	cout<<"enter "<<size<<" elements";

	for(int i=0; i<size;i++)
	{

		cin>>ptr[i];
	}
}
bool isprime(int num)
{
	if(num<2)
		return false;
	for(int i=2;i*i<=num;i++)
	{
		if(num%i==0)
		{
			return false;
		}
	}
	return true;
}

int  countprime(int* arr,int size)
{
	int count=0;
	for(int i=0;i<size;i++)
		{
		if(isprime(arr[i]))
			count++;
		}

return count;
}


int main()
{
	int* ptr=nullptr;
	int size;
	cout<<"enter size";
	cin>>size;
	allocateMemory(ptr,size);
	initialize(ptr,size);
	int primecount=countprime(ptr,size);
	cout<<"prime numbers are   "<<primecount;
    delete [] ptr;
    ptr=nullptr;

	return 0;
}
