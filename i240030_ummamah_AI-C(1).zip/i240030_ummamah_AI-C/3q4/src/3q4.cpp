//============================================================================
// Name        : 3q4.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
    int size = 5;
    char* p = new char[size];

    cout << "Enter " << size << " characters: ";
    for (int i = 0; i < size; i++) {
        cin >> *(p + i);
    }


    cout << "\nOriginal array: ";
    for (int i = 0; i < size; i++) {
        cout << *(p + i) << " ";
    }
    cout << endl;


    char* temp = new char[size];
    for (int i = 0; i < size; i++) {
        *(temp + i) = *(p + i);
    }


    delete[] p;
    p = NULL;


    int newSize = 7;
    p = new char[newSize];


    for (int i = 0; i < size; i++) {
        *(p + i) = *(temp + i);
    }


    cout << "Enter 2 more characters: ";
    for (int i = size; i < newSize; i++) {
        cin >> *(p + i);
    }


    cout << "\nNew array: ";
    for (int i = 0; i < newSize; i++) {
        cout << *(p + i) << " ";
    }
    cout << endl;


    delete[] p;
    delete[] temp;

    return 0;
}
