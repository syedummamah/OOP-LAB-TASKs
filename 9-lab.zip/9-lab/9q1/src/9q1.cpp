//============================================================================
// Name        : 9q1.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
class Darray{
	int *arr;
	int n;

	Darray(int n)
	{
		this->arr=new int [n];
	}

    Darray(const Darray&other){
    	n=n.other;
    	for(int i=0;i<n;i++)
    	{
          arr[i]=other.arr[i];
    	}
    }

    ~DArray() {
            delete[] arr;
        }
};
int main() {

 Darray d1;


	return 0;
}
