//============================================================================
// Name        : 9q2.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

using namespace std;

class Sequence {
private:
    int length;
    int* pseq;

public:
    // Default constructor
    Sequence() {
        length = 10;
        pseq = new int[length];
        for (int i = 0; i < length; i++) {
            pseq[i] = 0;
        }
    }

    // Parameterized constructor
    Sequence(int lengthVal, int n1=0, int n2=0, int n3=0,
             int n4=0, int n5=0, int n6=0, int n7=0, int n8=0,
             int n9=0, int n10=0) {
        length = lengthVal;
        pseq = new int[length];

        int values[] = {n1, n2, n3, n4, n5, n6, n7, n8, n9, n10}; // Collect values

        for (int i = 0; i < length; i++) {
            pseq[i] = (i < 10) ? values[i] : 0; // Fill up to 10 values, rest zero
        }
    }

    // Copy constructor
    Sequence(const Sequence &s) {
        length = s.length;
        pseq = new int[length];
        for (int i = 0; i < length; i++) {
            pseq[i] = s.pseq[i];
        }
    }

    // Getter for length
    int getLength() {
        return length;
    }

    // Getter for sequence array
    int* getSeq() {
        return pseq;
    }

    // Sorting
    void Sort() { // Remove parameter and use class member length
        for (int i = 0; i < length - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < length; j++) {
                if (pseq[j] < pseq[minIndex]) {
                    minIndex = j;
                }
            }
            swap(pseq[i], pseq[minIndex]); // Use built-in swap
        }
    }

    // Destructor
    ~Sequence() {
        delete[] pseq;
    }

    // Display function
    void display() {
        for (int i = 0; i < length; i++) {
            cout << pseq[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    Sequence seq1( 4, 2, 9, 1, 7);
    cout << "Original Sequence: ";
    seq1.display();

    seq1.Sort();
    cout << "Sorted Sequence: ";
    seq1.display();

    return 0;
}
