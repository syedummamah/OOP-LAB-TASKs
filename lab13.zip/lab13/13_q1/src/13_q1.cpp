//============================================================================
// Name        : 13_q1.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

struct Course{

	string subject;
	int courseID;
	Course(string sub=" ", int tit=0) :subject(sub), courseID(tit){}

};

struct Student{

	string name;
	int uniID;
	Student(string n=" " , int roll=0):name(n), uniID(roll){}


};

class Semester{
	struct Enrollment{
			int stuId;
			int courseId;

			void setValues(int cId, int rollNumber) {
				stuId = rollNumber;
				courseId = cId;
			}

			void display(){
				cout << "Course ID: " << courseId <<endl<<" Student ID: " <<stuId;
			}
	};
	int num;
	Enrollment *enroll;
	int index;

public:

	Semester (int n,int idx=0): num(n){
		enroll= new Enrollment[num];
		index=idx;
	}

	void enrollStudent(int course_id, int roll_ID) {
	        if (index < num) {
	            enroll[index++].setValues(course_id,roll_ID);
	        } else {
	            cout << "Cannot enroll more students" << endl;
	        }
	    }

	    void displayEnrollments() {
	        for (int i = 0; i < index; i++) {
	            enroll[i].display();

	        }
	    }

	    ~Semester() {
	        delete[] enroll;
	    }
};


int main() {



   Student student1("Huzaifa", 240052);

   Student student2("Raheen", 240111);

   Student student3("Ammar", 238210);



   Course course1("Math", 2001);

   Course course2("Physics", 2002);



   Semester spring2025(4);

   spring2025.enrollStudent(course1.courseID,student1.uniID);

   spring2025.enrollStudent(course1.courseID,student2.uniID);

   spring2025.enrollStudent(course2.courseID,student3.uniID);

   spring2025.enrollStudent(course2.courseID,student1.uniID);



   spring2025.displayEnrollments();



   return 0;

}
