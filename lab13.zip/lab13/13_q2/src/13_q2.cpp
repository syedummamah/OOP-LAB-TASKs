//============================================================================
// Name        : 13_q2.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

// Superclass: Shape
class Shape {
protected:
    string color;
    bool filled;
public:
    // Constructor
    Shape() {
        color = "green";
        filled = true;
    }

    Shape(string clr, bool fill) {
        color = clr;
        filled = fill;
    }

    string getColor() {
        return color;
    }

    void setColor(string clr) {
        color = clr;
    }

    bool isFilled() {
        return filled;
    }

    void setFilled(bool fill) {
        filled = fill;
    }

    virtual string toString() {
        return "A Shape with color of " + color + " and " + (filled ? "filled" : "Not filled");
    }
};

// Subclass: Circle
class Circle : public Shape {
private:
    double radius;
public:
    Circle() {
        radius = 1.0;
    }

    Circle(double r) {
        radius = r;
    }

    Circle(double r, string clr, bool fill) : Shape(clr, fill) {
        radius = r;
    }

    double getRadius() {
        return radius;
    }

    void setRadius(double r) {
        radius = r;
    }

    double getArea() {
        return radius * radius * 3.1416;
    }

    double getPerimeter() {
        return 2 * 3.1416 * radius;
    }

    string toString() override {
        return "A Circle with radius=" + to_string(radius) + ", which is a subclass of " + Shape::toString();
    }
};

// Subclass: Rectangle
class Rectangle : public Shape {
protected:
    double width;
    double length;
public:
    Rectangle() {
        width = 1.0;
        length = 1.0;
    }

    Rectangle(double w, double l) {
        width = w;
        length = l;
    }

    Rectangle(double w, double l, string clr, bool fill) : Shape(clr, fill) {
        width = w;
        length = l;
    }

    double getWidth() {
        return width;
    }

    virtual void setWidth(double w) {
        width = w;
    }

    double getLength() {
        return length;
    }

    virtual void setLength(double l) {
        length = l;
    }

    double getArea() {
        return width * length;
    }

    double getPerimeter() {
        return 2 * (width + length);
    }

    string toString() override {
        return "A Rectangle with width=" + to_string(width) + " and length=" + to_string(length)
            + ", which is a subclass of " + Shape::toString();
    }
};

// Subclass: Square
class Square : public Rectangle {
public:
    Square() {
        width = length = 1.0;
    }

    Square(double side) {
        width = length = side;
    }

    Square(double side, string clr, bool fill) : Rectangle(side, side, clr, fill) {}

    double getSide() {
        return width;
    }

    void setSide(double side) {
        width = length = side;
    }

    void setWidth(double side) override {
        width = length = side;
    }

    void setLength(double side) override {
        width = length = side;
    }

    string toString() override {
        return "A Square with side=" + to_string(width) + ", which is a subclass of " + Rectangle::toString();
    }
};

int main()
{

}
