//============================================================================
// Name        : 12_labq1.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
class Box{

	int length;
	int width;
	int height;


public:

	Box(int l, int w,int h):length(l),width(w),height(h){}

void display()
{
	cout<<"("<<length<<","<<width<<","<<height<<")"<<endl<<"volume is:"<<(length*width*height)<<endl;
}

  bool operator<(Box const &b)
		{
	       return (length*width*height)<(b.length*b.width*b.height);
		}
  bool operator>(Box const &b)
  		{
  	       return (length*width*height)>(b.length*b.width*b.height);
  		}
};





int main() {
Box box1(4, 5, 6);
Box box2(3, 6, 7);
cout << "Comparing boxes:" << endl;
box1.display();
box2.display();
if (box1 < box2)
cout << "Box 1 is smaller than Box 2" << endl;
else if (box1 > box2)
cout << "Box 1 is larger than Box 2" << endl;
else
cout << "Box 1 and Box 2 have equal volume" << endl;


return 0;
}
