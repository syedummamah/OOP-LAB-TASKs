//============================================================================
// Name        : 12_labq3.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

class Author {
    string name;
    int birthYear;
    string nationality;

public:
    Author() {}

    Author(string n, int y, string nat) : name(n), birthYear(y), nationality(nat) {}

    void setDetails(string n, int y, string nat) {
        name = n;
        birthYear = y;
        nationality = nat;
    }

    string getName() const {
        return name;
    }

    void display() const {
        cout << "Author Name: " << name
             << ", Birth Year: " << birthYear
             << ", Nationality: " << nationality << endl;
    }
};

class Book {
    string title;
    int publicationYear;
    Author &auth;

public:
    Book(Author &a) : auth(a) {}

    Book(string t, int y, Author &a) : title(t), publicationYear(y), auth(a) {}

    void setDetails(string t, int y) {
        title = t;
        publicationYear = y;
    }

    string getTitle() const {
        return title;
    }

    int getPublicationYear() const {
        return publicationYear;
    }

    Author getAuthor() const {
        return auth;
    }

    void display() const {
        cout << "Title: " << title
             << ", Year: " << publicationYear << endl;
        auth.display();
    }
};

class Library {
    Book* books[5];
    static int currentSize;

public:
    Library() {}

    void addBook(string title, int year, Author &auth) {
        if (currentSize < 5) {
            books[currentSize] = new Book(title, year, auth);
            currentSize++;
        } else {
            cout << "Library is full! Cannot add more books.\n";
        }
    }

    void displayAllBooks() const {
        for (int i = 0; i < currentSize; i++) {
            books[i]->display();
        }
    }

    void searchByTitle(string t) const {
        bool found = false;
        for (int i = 0; i < currentSize; i++) {
            if (books[i]->getTitle() == t) {
                cout << "Book found:\n";
                books[i]->display();
                found = true;
                break;
            }
        }
        if (!found) {
            cout << "Book with title \"" << t << "\" not found.\n";
        }
    }

    void searchByAuthor(string authorName) const {
        bool found = false;
        for (int i = 0; i < currentSize; i++) {
            if (books[i]->getAuthor().getName() == authorName) {
                books[i]->display();
                found = true;
            }
        }
        if (!found) {
            cout << "No books found by author \"" << authorName << "\".\n";
        }
    }
};

int Library::currentSize = 0;

int main() {
    // Create authors
    Author a1("F. Scott Fitzgerald", 1896, "American");
    Author a2("George Orwell", 1903, "British");
    Author a3("Harper Lee", 1926, "American");

    // Create library
    Library lib;

    // Add books with author objects
    lib.addBook("The Great Gatsby", 1925, a1);
    lib.addBook("1984", 1949, a2);
    lib.addBook("To Kill a Mockingbird", 1960, a3);

    cout << "\nAll Books in Library:\n";
    lib.displayAllBooks();

    cout << "\nSearching for book titled '1984':\n";
    lib.searchByTitle("1984");

    cout << "\nSearching for books by 'George Orwell':\n";
    lib.searchByAuthor("George Orwell");

    cout << "\nSearching for books by 'J.K. Rowling':\n";
    lib.searchByAuthor("J.K. Rowling");

    return 0;
}
