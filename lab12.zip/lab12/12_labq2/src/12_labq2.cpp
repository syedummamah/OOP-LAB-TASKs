//============================================================================
// Name        : 12_labq2.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
class Box {
private:
double dimensions[3]; // 0: length, 1: width, 2: height4

public:

Box(double l = 0, double w = 0, double h = 0) {
dimensions[0] = l;
dimensions[1] = w;
dimensions[2] = h;
}
    double&operator[](int Index)
    {
    	return dimensions[Index];
    }

  void display()
  {
	  for(int i=0;i<3;i++)
	  {
		  cout<<dimensions[i]<<" ";
	  }
  }

  ~Box(){}


};




int main() {
Box box(10, 20, 30);
cout << "Original dimensions:" << endl;
box.display();
cout << "\nAccessing via subscript operator:" << endl;
cout << "Length: " << box[0] << endl;
cout << "Width: " << box[1] << endl;
cout << "Height: " << box[2] << endl;

box[0] = 15;
box[1] = 25;
cout << "\nAfter modification:" << endl;
box.display();

return 0;
}
