//============================================================================
// Name        : 12_labq3.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
class Book{
string title;
string author;
string publisher;
int yearOfPublication;

public:
Book(){}

  Book (string t,string a,string p, int y):title(t),author(a),publisher(p),yearOfPublication(y){}
  void setTitle(string t){
	  title=t;
  }
  void setAuthor(string a){
	  author=a;
    }
  void setPublisher(string p){
	  publisher=p;
     }
  void setyop(int y){
	  yearOfPublication=y;
       }
  //getters
  string getTitle()
  {
	  return title;
  }
  string getAuthor(){
  	  return author;
      }
  string getPublisher(){
	 return publisher;
     }
  int getyop(){
	 return yearOfPublication;
       }
   void setDetails(string t,string a, string p,int y){
	   title=t;
	   author=a;
	   publisher=p;
	   yearOfPublication=y;

   }
   void display()
   {
	   cout<<"Title: "<<title<<"Author: "<<author<<"Publisher: "<<publisher<<"Year Of Publication: "<<yearOfPublication;
   }
};

class Library{
Book books[5]; // Array of Book objects
static int currentSize;

public:
  Library(){}

   void addBook(string t,string a, string p,int y)
   {
	   if (currentSize < 5) {
	               books[currentSize].setDetails(t, a, p, y);
	               currentSize++;
	           } else {
	               cout << "Library is full! Cannot add more books.\n";
	           }

   }
   void displayAllBooks(){

	   for(int i=0;i<currentSize;i++){

		   books[i].display();
	   }

   }

   void searchByTitle(string t) {
       bool found = false;
       for (int i = 0; i < currentSize; i++) {
           if (books[i].getTitle() == t) {
               cout << "Book found:\n";
               books[i].display();
               found = true;
               break;
           }
       }
       if (!found) {
           cout << "Book with title \"" << t << "\" not found.\n";
       }
   }
   void removeBookByTitle(string t) {
           bool found = false;
           for (int i = 0; i < currentSize; i++) {
               if (books[i].getTitle() == t) {
                   // Shift all books one step left
                   for (int j = i; j < currentSize - 1; j++) {
                       books[j] = books[j + 1];
                   }
                   currentSize--;
                   cout << "Book with title \"" << t << "\" has been removed.\n";
                   found = true;
                   break;
               }
           }
           if (!found) {
               cout << "Book with title \"" << t << "\" not found.\n";
           }
       }
   void displayBooksAfterYear(int y)
   {
	   bool found=false;
	   for (int i = 0; i < currentSize; i++) {
	               if (books[i].getyop() > y) {
	                   books[i].display();
	                   found = true;
	               }
	           }
	           if (!found) {
	               cout << "No books found published after " << y << ".\n";
	           }
	       }



};
int Library::currentSize=0;
int main() {

// Create a library
Library library;

// Adding books to the library using 4 arguments (no need to create Book objects separately)
library.addBook("The Great Gatsby", "F. Scott Fitzgerald", "Scribner", 1925);
library.addBook("1984", "George Orwell", "Secker & Warburg", 1949);
library.addBook("To Kill a Mockingbird", "Harper Lee", "J.B. Lippincott & Co.",1960);

// Display all books in the library
library.displayAllBooks();

// Search for a book by title
cout << "\nSearching for '1984':\n";
library.searchByTitle("1984");

// Remove a book by title (Bonus)
cout << "\nRemoving '1984' from the library:\n";
library.removeBookByTitle("1984");

// Display all books after removal
cout << "\nUpdated Library:\n";
library.displayAllBooks();

// Display books published after a certain year (Bonus)
cout << "\nDisplaying books published after 1950:\n";
library.displayBooksAfterYear(1950);

return 0;
}
