//============================================================================
// Name        : 1q3.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
	int a = 10;
		int *ptr = &a;

		cout << *ptr << endl;
		cout << &a << endl;
		cout << ptr << endl;
		cout << *ptr << endl;

		*ptr = 7;

		cout << a << endl;
		cout << *ptr << endl;

		a = 2;

		cout << *&a << endl;
		cout << *&ptr << endl;
		cout << *&*ptr << endl;
	return 0;
}
