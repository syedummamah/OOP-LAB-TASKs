//============================================================================
// Name        : 1q1.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
	int a,b;
	int*ptrA ,*ptrB;
	cout<<"Enter first variabe"<<endl;
	cin>>a;
	cout<<"Enter second variabe"<<endl;
	cin>>b;
	ptrA=&a;
	ptrB=&b;
    cout<<"Value of a:"<<a<<endl<<"Address of a :"<<ptrA<<endl;
    cout<<"Value of b:"<<b<<endl<<"Address of b :"<<ptrB<<endl;

	return 0;
}
