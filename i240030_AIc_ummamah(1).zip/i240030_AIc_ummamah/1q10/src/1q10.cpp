//============================================================================
// Name        : 1q10.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
void swap(int&a, int&b)
{   int temp=a;
	a=b;
	b=temp;

}
int main() {
	int a,b;

	cout<<"Enter number"<<endl;
	cin>>a>>b;
	swap(a,b);
	cout<<a<<" "<<b;
	return 0;
}
