//============================================================================
// Name        : 1q2.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
int main()
{
int a, b;
 cout << "\nUsing & as reference operator" << endl;
 a=10;
 int& ref = a;
 ref = 20;
 cout<<"Value of a:"<<a<<endl;

 cout<<endl<<"Using & as address of operator"<<endl;
 a=42;
 cout<<"Address of a: "<<&a<<endl;
 cout<<"Address of ref: "<<&ref<<endl;

 cout<<endl<<"Assigning value of b"<<endl;

 ref = b;
 cout<<"Address of ref: "<<&ref<<endl;
 cout<<"Value of ref: "<<ref<<endl;
 cout<<"Value of a: "<<a<<endl;
 return 0;
}
