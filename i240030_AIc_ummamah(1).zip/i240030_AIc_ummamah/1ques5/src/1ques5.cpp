//============================================================================
// Name        : 1ques5.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {

	int a = 10;
	int b = 5;
	const int *ptr;

	ptr = &a;
	ptr = &b;
	cout << *ptr;
	return 0;
}
