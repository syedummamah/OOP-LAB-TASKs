//============================================================================
// Name        : 1q4.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
	int arr[5] = {1, 21, 3, 4, 5};

	cout << arr << endl;
	cout << *arr << endl;
	cout << (arr+2) << endl;
	cout << *(arr+2) << endl;
	cout << arr+4 << endl;
	cout << *(arr+4) << endl;

	int *ptr = arr;

	cout << *++ptr << endl;
	cout << *++ptr << endl;

	return 0;
}
