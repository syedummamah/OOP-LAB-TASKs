//============================================================================
// Name        : 1q9.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
int add(int *a,int *b,int *c,int *d,int *e)
  {
	return *a+*b+*c+*d+*e;
}

int main() {
	int a,b,c,d,e;
	cout<<"enter 5 number to add"<<endl;
	cin>>a>>b>>c>>d>>e;
	cout<<add(&a,&b,&c,&d,&e);

	return 0;
}
