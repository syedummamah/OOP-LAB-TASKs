//============================================================================
// Name        : 1q11.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
void search (int arr)
{
	int max=*arr;
	int *ptr=arr;
for(int i=0;i<7;i++)
  {
	if(*(ptr+i)>max)
	{
		max=*(ptr+i);
	}
  }


	cout<<"LARGEST VALUE IS "<<*arr;

}
int main() {
  int arr[7]={1,2,3,4,5,6,7,8};
  search(arr);
			return 0;
}
