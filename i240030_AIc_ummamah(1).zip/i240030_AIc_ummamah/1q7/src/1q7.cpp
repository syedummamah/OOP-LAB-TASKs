//============================================================================
// Name        : 1q7.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
	const int a = 10;
	int b = 7;
	const int *ptr;

	ptr = &a;
	ptr = &b;
	*ptr = 20;
	cout << *ptr;
	return 0;
}
