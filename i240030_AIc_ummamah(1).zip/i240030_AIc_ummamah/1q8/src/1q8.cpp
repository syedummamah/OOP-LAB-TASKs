//============================================================================
// Name        : 1q8.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
	int a = 10;
	int b = 5;
	int *const ptr = &a;

	cout << ptr << endl;
	cout << *ptr << endl;

	*ptr = 66;
	cout << a++ << endl;
	cout << a;
	return 0;
}
