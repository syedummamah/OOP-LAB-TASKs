//============================================================================
// Name        : 4q1.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
void allocateMatrix(int**& matrix,int n)
 {
    matrix=new int*[n];
    for(int i=0;i<n;i++)
    {
    	matrix[i]=new int[n];
    }


 }
void inputMatrix(int** matrix,int n)
{
	for(int i=0;i<n;i++)
	{ for(int j=0;j<n;j++)
	 {
		cin>> matrix[i][j];
	}

	}
}
 void displayMatrix(int** matrix,int n)
 {
	 for(int i=0;i<n;i++)
	 	{ for(int j=0;j<n;j++)
	 	 {
	 		cout<<matrix[i][j];
	 	}
	 	cout<<endl;

	 	}
 }
 int sumOfRightDiagonal(int**& matrix,int n)
 {
	 int mainDiagSum= 0;
	     for (int i = 0; i < n; i++) {
	         mainDiagSum += matrix[i][i];
	     }
	     return mainDiagSum;
 }

void  deallocateMatrix(int**& matrix,int n)
{
	for(int i=0;i<n;i++)
	    {
	    	delete [] matrix[i];
	    }
	delete [] matrix;
	matrix=nullptr;

}

/*

int main() {
int n;
cout << "Enter the size of the square matrix: ";
cin >> n;
int **matrix;
allocateMatrix(matrix,n);
inputMatrix(matrix,n);
displayMatrix(matrix,n);
int sum = sumOfRightDiagonal(matrix,n);
deallocateMatrix(matrix,n);
// Display the sum of the right diagonal
cout << "Sum of the right diagonal is: " << sum << endl;
return 0;
}
*/
