#include "4q1.cpp"
#include <gtest/gtest.h>

void initializeMatrix(int **&matrix, int dimension, int startingNumber) {
    for (int i = 0; i < dimension; i++) {
        for (int j = 0; j < dimension; j++) {
            matrix[i][j] = startingNumber++;
        }
    }
}

TEST(RightDiagonalSums, size5) { 
    int ** matrix;
    int n = 5;
    allocateMatrix(matrix,n);

    initializeMatrix(matrix,n,-9);
    int sum = sumOfRightDiagonal(matrix,n);
    ASSERT_EQ(15, sum);

    initializeMatrix(matrix,n,0);
    sum = sumOfRightDiagonal(matrix,n);
    ASSERT_EQ(60, sum);

    initializeMatrix(matrix,n,6);
    sum = sumOfRightDiagonal(matrix,n);
    ASSERT_EQ(90, sum);

    deallocateMatrix(matrix,n);
    
}

TEST(RightDiagonalSums, size3) { 
    int ** matrix;
    int n = 3;
    allocateMatrix(matrix,n);

    initializeMatrix(matrix,n,6);
    int sum = sumOfRightDiagonal(matrix,n);
    ASSERT_EQ(30, sum);

    initializeMatrix(matrix,n,2);
    sum = sumOfRightDiagonal(matrix,n);
    ASSERT_EQ(18, sum);

    initializeMatrix(matrix,n,-15);
    sum = sumOfRightDiagonal(matrix,n);
    ASSERT_EQ(-33, sum);

    deallocateMatrix(matrix,n);
    
}



int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
