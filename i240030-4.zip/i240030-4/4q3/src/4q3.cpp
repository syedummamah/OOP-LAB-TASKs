//============================================================================
// Name        : 4q3.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
void initializeMatrix(int **&matrix, int row, int col, int startingNumber) {
     for (int i = 0; i < row; i++) {
         for (int j = 0; j < col; j++) {
             matrix[i][j] = startingNumber++;
       }
    }
 }

void allocateMatrix(int** & matrix,int r,int c)
{
	matrix=new int*[r];
	for(int i=0;i<r;i++)
	{
		matrix[i]=new int[c];
	}
}
void inputMatrix(int**& matrix,int r,int c)
{    cout<<"enter values of matrix"<<endl;
	for(int i=0;i<r;i++)
	{
		for(int j=0;j<c;j++)
		{
			cin>>matrix[i][j];
		}
		cout<<endl;
	}
}
void displayMatrix(int** matrix,int r,int c)
{
	for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				cout<<matrix[i][j];
			}
		}
}
void multiply(int** matrix1,int** matrix2,int **matrix3,int r1,int c1,int r2,int c2)
{
	for(int i=0;i<r1;i++)
	{
		for(int j=0;j<c2;j++)
		{
			matrix3[i][j]=0;
			for(int k=0;k<c1;k++)
			{
				matrix3[i][j]+=matrix1[i][k]*matrix2[k][j];
			}
		}
	}

}
void deallocateMatrix(int**& matrix1,int r1)
{
	for(int i=0;i<r1;i++)
	{
		delete[] matrix1[i];
	}
	    delete[] matrix1;
	    matrix1=nullptr;
}

/*

int main(){
int **matrix1;
int **matrix2;
int **matrix3;
int r1=2,c1=2;
int r2=2,c2=6;
allocateMatrix(matrix1,r1,c1);
allocateMatrix(matrix2,r2,c2);
inputMatrix(matrix1,r1,c1);
inputMatrix(matrix2,r2,c2);
displayMatrix(matrix1,r1,c1);
cout << endl;
displayMatrix(matrix2,r2,c2);
if (c1 != r2) {
	cout << "Matrix multiplication is not possible!" << endl;
  return 0;
}
allocateMatrix(matrix3,r1,c2);
multiply(matrix1,matrix2,matrix3,r1,c1,r2,c2);
cout << endl;
displayMatrix(matrix3,r1,c2);
deallocateMatrix(matrix1,r1);
deallocateMatrix(matrix2,r2);
deallocateMatrix(matrix3,r1);
return 0;
}
*/
