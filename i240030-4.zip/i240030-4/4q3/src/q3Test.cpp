#include "4q3.cpp"
#include <gtest/gtest.h>

 void initializeMatrix(int **&matrix, int row, int col, int startingNumber) {
    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
   matrix[i][j] = startingNumber++;
         }
     }
 }


TEST(multiply, test1) { 
    int ** matrix1;
    int ** matrix2;
    int **matrix3;

    int r1=3,c1=4;
    int r2=4,c2=2;

    allocateMatrix(matrix1,r1,c1);
    allocateMatrix(matrix2,r2,c2);

    initializeMatrix(matrix1,r1,c1,10);
    initializeMatrix(matrix2,r2,c2,5);

    multiply(matrix1,matrix2,matrix3,r1,c1,r2,c2);
    ASSERT_EQ(378,matrix3[0][0]);
    ASSERT_EQ(568,matrix3[1][1]);
    ASSERT_EQ(712,matrix3[2][1]);


    deallocateMatrix(matrix1,r1);
    deallocateMatrix(matrix2,r2);
    deallocateMatrix(matrix3,r1);
    
}

TEST(multiply, test2) { 
    int ** matrix1;
    int ** matrix2;
    int **matrix3;

    int r1=2,c1=2;
    int r2=2,c2=6;

    allocateMatrix(matrix1,r1,c1);
    allocateMatrix(matrix2,r2,c2);

    initializeMatrix(matrix1,r1,c1,5);
    initializeMatrix(matrix2,r2,c2,3);

    multiply(matrix1,matrix2,matrix3,r1,c1,r2,c2);
    ASSERT_EQ(69,matrix3[0][0]);
    ASSERT_EQ(124,matrix3[0][5]);
    ASSERT_EQ(108,matrix3[1][1]);


    deallocateMatrix(matrix1,r1);
    deallocateMatrix(matrix2,r2);
    deallocateMatrix(matrix3,r1);
    
}



int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
