#include "4q2.cpp"
#include <gtest/gtest.h>

void initializeMatrix(int **&matrix, int dimension, int startingNumber) {
    for (int i = 0; i < dimension; i++) {
        for (int j = 0; j < dimension; j++) {
            matrix[i][j] = startingNumber++;
        }
    }
}


TEST(isEqual, size4) { 
    int ** matrix1;
    int ** matrix2;
    int n = 4;
    allocateMatrix(matrix1,n);
    allocateMatrix(matrix2,n);

    initializeMatrix(matrix1,n,-9);
    initializeMatrix(matrix2,n,-9);
    ASSERT_TRUE(isEqual(matrix1,matrix2,n));

    initializeMatrix(matrix1,n,20);
    initializeMatrix(matrix2,n,20);
    ASSERT_TRUE(isEqual(matrix1,matrix2,n));

    initializeMatrix(matrix1,n,17);
    initializeMatrix(matrix2,n,21);
    ASSERT_FALSE(isEqual(matrix1,matrix2,n));

    deallocateMatrix(matrix1,n);
    deallocateMatrix(matrix2,n);
    
}

TEST(isEqual, size7) { 
    int ** matrix1;
    int ** matrix2;
    int n = 7;
    allocateMatrix(matrix1,n);
    allocateMatrix(matrix2,n);

    initializeMatrix(matrix1,n,0);
    initializeMatrix(matrix2,n,-1);
    ASSERT_FALSE(isEqual(matrix1,matrix2,n));

    initializeMatrix(matrix1,n,7);
    initializeMatrix(matrix2,n,7);
    ASSERT_TRUE(isEqual(matrix1,matrix2,n));

    initializeMatrix(matrix1,n,7);
    initializeMatrix(matrix2,n,18);
    ASSERT_FALSE(isEqual(matrix1,matrix2,n));

    deallocateMatrix(matrix1,n);
    deallocateMatrix(matrix2,n);
    
}



int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
