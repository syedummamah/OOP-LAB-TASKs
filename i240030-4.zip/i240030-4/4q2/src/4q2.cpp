//============================================================================
// Name        : 4q2.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
void allocateMatrix(int** & matrix,int n)
{
	matrix=new int*[n];
	{
		for(int i=0;i<n;i++)
		{
			matrix[i]=new int[n];
		}
	}

}
void inputMatrix(int** matrix,int n)
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cin>>matrix[i][j];
		}
	}
}
void displayMatrix(int** matrix1,int n)
{
	for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				cout<<matrix1[i][j];
			}
			cout<<endl;
		}
}
bool isEqual(int** &matrix1,int**& matrix2,int n)
{
	for(int i=0;i<n;i++)
	{   for(int j=0;j<n;j++)
	{
		if(matrix1[i][j]==matrix2[i][j])
		{
			return true;
		}
	}
	}
	return false;
}
void  deallocateMatrix(int**& matrix,int n)
{
	for(int i=0;i<n;i++)
	    {
	    	delete [] matrix[i];
	    }
	delete [] matrix;
	matrix=nullptr;

}





/*
int main() {
int n;
cout << "Enter the size of the square matrix: ";
cin >> n;
int **matrix1;
int **matrix2;
allocateMatrix(matrix1,n);
allocateMatrix(matrix2,n);
inputMatrix(matrix1,n);
inputMatrix(matrix2,n);
displayMatrix(matrix1,n);
displayMatrix(matrix2,n);
bool flag = isEqual(matrix1,matrix2,n);

deallocateMatrix(matrix1,n);
deallocateMatrix(matrix2,n);

cout << "Flag =" << flag << endl;
return 0;
}
*/
