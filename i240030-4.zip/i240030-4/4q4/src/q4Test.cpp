#include <gtest/gtest.h>

using namespace std;

// GTest Cases for array intersection
TEST(ArrayTests, IntersectionBasic) {
    int nums1[] = {1, 2, 2, 3, 4};
    int nums2[] = {2, 3, 5};
    int resultSize;
    int* result = arrayIntersection(nums1, 5, nums2, 3, resultSize);
    EXPECT_EQ(resultSize, 2);
    EXPECT_TRUE((result[0] == 2 && result[1] == 3) || (result[0] == 3 && result[1] == 2));
    delete[] result;
}

TEST(ArrayTests, IntersectionNoCommon) {
    int nums1[] = {1, 6, 7};
    int nums2[] = {2, 3, 5};
    int resultSize;
    int* result = arrayIntersection(nums1, 3, nums2, 3, resultSize);
    EXPECT_EQ(resultSize, 0);
    delete[] result;
}

TEST(ArrayTests, IntersectionAllCommon) {
    int nums1[] = {4, 5, 6};
    int nums2[] = {6, 5, 4};
    int resultSize;
    int* result = arrayIntersection(nums1, 3, nums2, 3, resultSize);
    EXPECT_EQ(resultSize, 3);
    EXPECT_TRUE((result[0] == 4 || result[0] == 5 || result[0] == 6));
    delete[] result;
}

// Main function for running tests
int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
