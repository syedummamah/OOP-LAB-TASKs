//============================================================================
// Name        : 4q4.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

void allocateArray(int* &arr, int size) {
    arr = new int[size];
}

void inputArray(int* arr, int size) {
    cout << "Enter " << size << " elements: ";
    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }
}
void displayArray(int* arr, int size) {
    cout << "Array: ";
    for (int i = 0; i < size; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}
bool isPresent(int* arr, int size, int num) {
    for (int i = 0; i < size; i++) {
        if (arr[i] == num) return true;
    }
    return false;
}
int* findIntersection(int* arr1, int size1, int* arr2, int size2, int &resultSize) {
    int* tempArray = new int[size1];
    int count = 0;

    for (int i = 0; i < size1; i++) {
        for (int j = 0; j < size2; j++) {
            if (arr1[i] == arr2[j]) {
                if (!isPresent(tempArray, count, arr1[i])) {
                    tempArray[count++] = arr1[i];
                }
                break;
            }
        }
    }
    if (count == 0) {
        resultSize = 0;
        delete[] tempArray;
        return new int[0];
    }

    int* resultArray = new int[count];
    for (int i = 0; i < count; i++) {
        resultArray[i] = tempArray[i];
    }

    delete[] tempArray;
    resultSize = count;
    return resultArray;
}

// int main() {
//     int size1, size2;
//     cout << "Enter size of first array: ";
//     cin >> size1;
//     cout << "Enter size of second array: ";
//     cin >> size2;

//     int* array1;
//     int* array2;

//     allocateArray(array1, size1);
//     allocateArray(array2, size2);

//     cout << "Input first array:\n";
//     inputArray(array1, size1);

//     cout << "Input second array:\n";
//     inputArray(array2, size2);

//     cout << "First ";
//     displayArray(array1, size1);

//     cout << "Second ";
//     displayArray(array2, size2);

//     int resultSize;
//     int* resultArray = findIntersection(array1, size1, array2, size2, resultSize);

//     if (resultArray != nullptr) {
//         cout << "Intersection ";
//         displayArray(resultArray, resultSize);
//         deallocateArray(resultArray);
//     } else {
//         cout << "No common elements found.\n";
//     }

//     deallocateArray(array1);
//     deallocateArray(array2);

//     return 0;
// }
