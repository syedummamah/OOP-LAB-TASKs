//============================================================================
// Name        : 4q5.cpp
// Author      : ummamah
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

void allocateMatrix(int **&matrix,int r,int c){


	matrix=new int*[r];

	for(int i=0;i<r;i++){

		matrix[i]=new int[c];

	}

}

void inputMatrix(int **matrix,int r,int c){


	for(int i=0;i<r;i++){

		for(int j=0;j<c;j++){

			cin>>matrix[i][j];

		}

	}

}

void displayMatrix(int **matrix,int r,int c){


	for(int i=0;i<r;i++){

		for(int j=0;j<c;j++){

			cout<<matrix[i][j]<<" ";

		}

		cout<<endl;

	}

}

int sumation(int **matrix,int r,int c){

	int sum;

	for(int i=0;i<r;i++){

		for(int j=0;j<c;j++){

			sum+=matrix[i][j];

		}


	}

return sum;

}

int maximum(int **matrix,int r,int c){

	int max=matrix[0][0];

	for(int i=0;i<r;i++){

		for(int j=0;j<c;j++){

			if(matrix[i][j]>max){

				max=matrix[i][j];

	}

		}


			}

	return max;

}

int findElement(int **matrix,int r,int c,int element){

	for(int i=0;i<r;i++){

		for(int j=0;j<c;j++){

			if(matrix[i][j]==element){

				return matrix[i][j];

	}

		}


			}


}


int largestRow(int **matrix,int r,int c){

	int sum=0;

	int temp=0;

	int Final=0;

	for(int i=0;i<r;i++){

		temp=sum;

		for(int j=0;j<c;j++){

		sum+=matrix[i][j];

	}if(sum>temp){

		Final=sum;

		}


			}

	return Final;

}

bool identity(int**matrix,int r,int c){

	bool ident=false;

  for(int i=0;i<r;i++){

	  for(int j=0;j<c;j++){

		if(i==j&&matrix[i][j]==1){ident=true;}

		else if(i!=j&&matrix[i][j]==0){ident=true;}

	  }

  }

  return ident;

}


int main() {


}
