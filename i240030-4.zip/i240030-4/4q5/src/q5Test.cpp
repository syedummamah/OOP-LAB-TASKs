#include <gtest/gtest.h>

using namespace std;

// GTest Cases
TEST(MatrixTests, SumElements) {
    int values[2][3] = {{1, 2, 3}, {4, 5, 6}};
    int** arr = create2DArray(2, 3, values);
    EXPECT_EQ(sumElements(arr, 2, 3), 21);
    delete2DArray(arr, 2);
}

TEST(MatrixTests, FindLargest) {
    int values[2][3] = {{5, 8, 10}, {3, 7, 2}};
    int** arr = create2DArray(2, 3, values);
    EXPECT_EQ(findLargest(arr, 2, 3), 10);
    delete2DArray(arr, 2);
}

TEST(MatrixTests, SearchElement) {
    int values[2][3] = {{5, 8, 9}, {3, 7, 1}};
    int** arr = create2DArray(2, 3, values);
    EXPECT_TRUE(searchElement(arr, 2, 3, 7));
    EXPECT_FALSE(searchElement(arr, 2, 3, 10));
    delete2DArray(arr, 2);
}

TEST(MatrixTests, RowWithMaxSum) {
    int values[3][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int** arr = create2DArray(3, 3, values);
    EXPECT_EQ(rowWithMaxSum(arr, 3, 3), 2);
    delete2DArray(arr, 3);
}

TEST(MatrixTests, IsIdentityMatrix) {
    int identity[3][3] = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
    int nonIdentity[2][2] = {{1, 2}, {3, 4}};
    int** idMatrix = create2DArray(3, 3, identity);
    int** nonIdMatrix = create2DArray(2, 2, nonIdentity);
    EXPECT_TRUE(isIdentityMatrix(idMatrix, 3, 3));
    EXPECT_FALSE(isIdentityMatrix(nonIdMatrix, 2, 2));
    delete2DArray(idMatrix, 3);
    delete2DArray(nonIdMatrix, 2);
}

// Main function for running tests
int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
